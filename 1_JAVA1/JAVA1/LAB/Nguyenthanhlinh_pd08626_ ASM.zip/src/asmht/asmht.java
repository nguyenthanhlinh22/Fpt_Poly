/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asmht;

import controller.NhanVienController;

public class asmht {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        menu();
    }
    public static void menu() {
        NhanVienController controller = new NhanVienController();

        do {
            System.out.println("");
            System.out.println("Menu chương trình");
            System.out.println("1. Nhập danh sách");
            System.out.println("2. Xuất danh sách");
            System.out.println("3. Tìm theo mã số");
            System.out.println("4. Xóa theo mã số");
            System.out.println("5. Cập nhật theo mã số");
            System.out.println("6. Tìm theo khoảng lương");
            System.out.println("7. Sắp xếp theo họ tên");
            System.out.println("8. Sắp xếp theo thu nhập");
            System.out.println("9. In 5 nhân viên thu nhập cao nhất");
            System.out.println("10. Thoát");

            int chon = controller.validationInteger("[1-9]|10", "Chọn [1-10]: ");
            System.out.println("");
            switch (chon) {
                case 1: {
                    controller.nhapDanhSach();
                    break;
                }
                case 2: {
                    controller.xuatDanhSach();
                    break;
                }
                case 3: {
                    controller.timTheoMaSo();
                    break;
                }
                case 4: {
                    controller.xoaTheoMaSo();
                    break;
                }
                case 5: {
                    controller.capNhatTheoMa();
                    break;
                }
                case 6: {
                    controller.timTheoKhoangLuong();
                    break;
                }
                case 7: {
                    controller.sapXepTheoHoTen();
                    break;
                }
                case 8: {
                    controller.sapXepTheoThuNhap();
                    break;
                }
                case 9: {
                    controller.in5NhanVienThuNhapCaoNhat();
                    break;
                }
                case 10: {
                    System.out.println("Tạm biệt!");
                    return;
                }
                default: {
                    break;
                }
            }
        } while (true);
    }
}

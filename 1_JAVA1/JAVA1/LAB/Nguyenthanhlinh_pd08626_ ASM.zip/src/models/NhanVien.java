/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author MY PC
 */
public class NhanVien {
    private String maSo;
    private String hoTen;
    private Double luong;

    public Double getThueThuNhap() {
        //Dưới 9 triệu: không đóng thuế
//o Từ 9-15 triệu: đóng 10%
//o Trên 15 triệu: đóng 12%
        Double thue = 0.0;
        if (luong < 9000000) {
            thue = 0.0;
        } else if (luong >= 9000000 && luong <= 15000000) {
            thue = luong * 0.1;
        } else if (luong > 15000000) {
            thue = luong * 0.12;
        }
        return thue;
    }

    public Double getThuNhap() {
        Double thuNhap = luong - getThueThuNhap();
        return thuNhap;
    }

    public void inThongTin() {
        System.out.println("Tên: "+hoTen +"  Thu nhập: "+getThuNhap());
    }

    public NhanVien() {
    }

    public NhanVien(String maSo, String hoTen, Double luong) {
        this.maSo = maSo;
        this.hoTen = hoTen;
        this.luong = luong;
    }

    public String getMaSo() {
        return maSo;
    }

    public void setMaSo(String maSo) {
        this.maSo = maSo;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public Double getLuong() {
        return luong;
    }

    public void setLuong(Double luong) {
        this.luong = luong;
    }

}

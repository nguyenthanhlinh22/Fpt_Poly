/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import models.NhanVien;

/**
 *
 * @author MY PC
 */
public class NhanVienController {
     ArrayList<NhanVien> danhSach = new ArrayList<NhanVien>();
     public void nhapDanhSach() {
        int soLuong = validationInteger("\\d{1,}","Nhập số lượng nhân viên: ");


        for (int i = 0; i < soLuong; i++) {

            String maSo = validationString("NV\\d{3}", "Nhập mã số: ");
            String hoTen = validationString("[a-zA-Z]+", "Nhập họ tên: ");

            Double luong = validationDouble("[1-9][0-9]{6,}", "Nhập tiền lương: ");

            NhanVien nhanVien = new NhanVien(maSo, hoTen, luong);
            danhSach.add(nhanVien);
        }
    }
    public void xuatDanhSach(){
        for(NhanVien nhanVien : danhSach){
            nhanVien.inThongTin();
        }
    }
    public void timTheoMaSo(){
        String maSo = validationString("NV\\d{3}", "Nhập mã số cần tìm: ");
        int index = -1;
        for (int i = 0; i < danhSach.size(); i++) {
            NhanVien nhanVien = danhSach.get(i);
            if(nhanVien.getMaSo().equals(maSo)){
                index = i;
                break;
            }
        }
        if(index == -1){
            System.out.println("Không tìm thấy nhân viên");
        }else{
            NhanVien nhanVien = danhSach.get(index);
            nhanVien.inThongTin();
        }
    }
    public void xoaTheoMaSo(){
    String maSo = validationString("NV\\d{3}", "Nhập theo mã số cần xóa: ");
    int index = -1;
        for (int i = 0; i < danhSach.size(); i++) {
            NhanVien nhanVien = danhSach.get(i);
            if(nhanVien.getMaSo().equals(maSo)){
                index = i;
                break;
            }
        }
        if(index == -1){
            System.out.println("Không tìm thấy nhân viên");
        }else{
            danhSach.remove(index);
            System.out.println("Xóa thành công!");
        }
            
    }
    public void capNhatTheoMa(){
        String maSo = validationString("NV\\d{3}", "Nhập theo mã số cần cập nhật: ");
        int index = -1;
        for (int i = 0; i < danhSach.size(); i++) {
            NhanVien nhanVien = danhSach.get(i);
            if (nhanVien.getMaSo().equals(maSo)) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            System.out.println("Không tìm thấy nhân viên");
        } else {
            //cập nhật thông tin họ tên, lương
            String hoTen = validationString("[a-zA-Z]+", "Nhập họ tên mới: ");
            Double luong = validationDouble("[1-9][0-9]{6,}", "Nhập tiền lương mới: ");
            danhSach.get(index).setHoTen(hoTen);
            danhSach.get(index).setLuong(luong);
            System.out.println("");
            System.out.println("Cập nhật thành công!");
        }
    }
    public void timTheoKhoangLuong(){
     Double luongChanDuoi = validationDouble("[1-9][0-9]{6,}", "Nhập tiền lương [Min] : ");
     Double luongChanTren = validationDouble("[1-9][0-9]{6,}", "Nhập tiền lương [Max]: ");
        System.out.println("");
     if(luongChanDuoi > luongChanTren){
         Double tam = luongChanDuoi;
         luongChanDuoi = luongChanTren;
         luongChanTren = tam;
     }
        for (NhanVien nhanVien : danhSach) {
            if(nhanVien.getLuong() >= luongChanDuoi && nhanVien.getLuong() <= luongChanTren){
                nhanVien.inThongTin();
            }
        }
    }
    public void sapXepTheoHoTen(){
        Comparator<NhanVien> comparator = new Comparator<NhanVien>() {
            @Override
            public int compare(NhanVien o1, NhanVien o2) {
                //sắp xếp tăng dần
                return o1.getHoTen().compareTo(o2.getHoTen());
                //sắp xếp giảm dần
//                return o2.getHoTen().compareTo(o1.getHoTen());
            }
        };
        Collections.sort(danhSach,comparator);
    }
    public void sapXepTheoThuNhap(){
    Comparator<NhanVien> comparator = new Comparator<NhanVien>() {
            @Override
            public int compare(NhanVien o1, NhanVien o2) {
                //sắp xếp tăng dần
//                return o1.getThuNhap().compareTo(o2.getThuNhap());
                //sắp xếp giảm dần
                return o2.getThuNhap().compareTo(o1.getThuNhap());
            }
        };
        Collections.sort(danhSach, comparator);
    }

    public void in5NhanVienThuNhapCaoNhat() {
        //sắp xếp theo thu nhập giảm dần
        //in ra 5 nhân viên đầu tiên

        
        //sắp xếp giảm dần
        Comparator<NhanVien> comparator = new Comparator<NhanVien>() {
            @Override
            public int compare(NhanVien o1, NhanVien o2) {
                //sắp xếp tăng dần
//                return o1.getThuNhap().compareTo(o2.getThuNhap());
                //sắp xếp giảm dần
                return o2.getThuNhap().compareTo(o1.getThuNhap());
            }
        };
        Collections.sort(danhSach, comparator);
        
        //in ra 5 nhân viên đầu tiên
        for (int i = 0; i < Math.min(5, danhSach.size()); i++) {
            danhSach.get(i).inThongTin();
        }
    }
     public String validationString(String pattern, String label) {
        Scanner scanner = new Scanner(System.in);
        String str = "";

        do {
            System.out.print(label);
            str = scanner.nextLine();
            if (str.matches(pattern)) {
                break;
            }
        } while (true);
        return str;
    }
    public Double validationDouble(String pattern, String label) {
        Scanner scanner = new Scanner(System.in);
        String str = "";

        do {
            System.out.print(label);
            str = scanner.nextLine();
            if (str.matches(pattern)) {
                break;
            }
        } while (true);
        return Double.parseDouble(str);
    }
    public Integer validationInteger(String pattern, String label) {
        Scanner scanner = new Scanner(System.in);
        String str = "";

        do {
            System.out.print(label);
            str = scanner.nextLine();
            if (str.matches(pattern)) {
                break;
            }
        } while (true);
        return Integer.parseInt(str);
    }
}
